#coding=utf-8
from django.shortcuts import render
from app.models import Customer
from django.shortcuts import render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from django.template import RequestContext
from django import forms
from models import User
# Create your views here.
def index(request):
    if  not request.REQUEST.has_key("dish"):
        tot = Customer.objects.count()
        tot_a=Customer.objects.filter(kind='A').count()
        tot_b=Customer.objects.filter(kind='B').count()
        tot_c=Customer.objects.filter(kind='C').count()
        return render_to_response('app/index.html', {'tot':tot,'tot_a':tot_a,'tot_b':tot_b,'tot_c':tot_c,'dishes':'A'})
    else:
        kind = request.GET['dish']
        person = Customer(kind=kind, num=0)
        person.save()
        tot = Customer.objects.count()
        tot_a=Customer.objects.filter(kind='A').count()
        tot_b=Customer.objects.filter(kind='B').count()
        tot_c=Customer.objects.filter(kind='C').count()
        id = Customer.objects.last().id
        return render_to_response('app/index.html', {'tot':tot,'tot_a':tot_a,'tot_b':tot_b,'tot_c':tot_c,'id':id,'kind':kind,'dishes':'A'})
        
    
    
def homepage(request):
    if request.REQUEST.has_key("dish"):
        kind = request.GET['dish']
        Customer.objects.filter(kind=kind).first().delete()
    tot = Customer.objects.count()
    tot_a=Customer.objects.filter(kind='A').count()
    tot_b=Customer.objects.filter(kind='B').count()
    tot_c=Customer.objects.filter(kind='C').count()
	
    num_a = Customer.objects.filter(kind='A').first().id
    num_b = Customer.objects.filter(kind='B').first().id
    num_c = Customer.objects.filter(kind='C').first().id			
    return render_to_response('app/homepage.html',{'tot':tot,'tot_a':tot_a,'tot_b':tot_b,'tot_c':tot_c,'num_a':num_a,'num_b':num_b,'num_c':num_c})

def test(request):
    dish = request.GET['dish']
    return render_to_response('app/test.html',{'dish':dish})

    
def DB(request):
    return render(request,'app/DB.html')


class UserForm(forms.Form): 
    username = forms.CharField(label='用户名',max_length=100)
    password = forms.CharField(label='密码',widget=forms.PasswordInput())
	
	#注册
def regist(req):
    if req.method == 'POST':
        uf = UserForm(req.POST)
        if uf.is_valid():
            #获得表单数据
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            #添加到数据库
            User.objects.create(username=username,password=password)
            return HttpResponseRedirect('login')
    else:
        uf = UserForm()
    return render_to_response('app/regist.html',{'uf':uf}, context_instance=RequestContext(req))
#登陆
def login(req):
    if req.method == 'POST':
        uf = UserForm(req.POST)
        if uf.is_valid():
            #获取表单用户密码
            username = uf.cleaned_data['username']
            password = uf.cleaned_data['password']
            #获取的表单数据与数据库进行比较
            user = User.objects.filter(username__exact = username,password__exact = password)
            if user:
                #比较成功，跳转index
                response = HttpResponseRedirect('homepage')
                #将username写入浏览器cookie,失效时间为3600
                return response
            else:
                #比较失败，还在login
                return HttpResponseRedirect('login')
    else:
        uf = UserForm()
    return render_to_response('app/login.html',{'uf':uf},context_instance=RequestContext(req))

#登陆成功
def welcome(req):
    username = req.COOKIES.get('username','')
    return render_to_response('app/welcome.html' ,{'username':username})