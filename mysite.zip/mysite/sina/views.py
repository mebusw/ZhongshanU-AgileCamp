from django.shortcuts import render
from django.http import HttpResponse
# import splite3
# Create your views here.
def index(request):
	return render(request,'sina/index.html')
	
def homepage(request):
	return render(request,'sina/homepage.html')
	
def test(request):
	return render(request,'sina/test.html')
	
#def operate(request):
	##operate connection DB
	##
	
#	return render