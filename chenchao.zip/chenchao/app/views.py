from django.shortcuts import render
from django.http import HttpResponse
from app.models import Customer
# Create your views here.
def index(request):
    return render(request,'app/index.html')
    
def homepage(request):
    return render(request,'app/homepage.html')

def test(request):
    return render(request,'app/test.html')

def DB(request):
    return render(request,'app/DB.html')

def add(request):
    name = request.GET['name']
    kind = request.GET['kind']
    person = Customer(name=name, kind=kind, num=1)
    person.save()
    return HttpResponse(name + ' ' + kind)